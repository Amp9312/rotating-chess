import type {
    Color,
    Rotation,
    Square,
} from "../types";

import {
    coordinatesToSquare,
    squareToCoordinates,
} from "./coordinates";

export interface Coordinate {
    fileIndex: number;
    rankIndex: number;
}

/**
 * Convert a logical board coordinate into its
 * current physical/display coordinate.
 *
 * Logical coordinates never change.
 * Physical coordinates change with board rotation.
 */
export function logicalToPhysical(
    coordinate: Coordinate,
    rotation: Rotation
): Coordinate {
    const {
        fileIndex,
        rankIndex,
    } = coordinate;

    switch (rotation) {
        case 0:
            return {
                fileIndex,
                rankIndex,
            };

        case 90:
            return {
                fileIndex: 7 - rankIndex,
                rankIndex: fileIndex,
            };

        case 180:
            return {
                fileIndex: 7 - fileIndex,
                rankIndex: 7 - rankIndex,
            };

        case 270:
            return {
                fileIndex: rankIndex,
                rankIndex: 7 - fileIndex,
            };
    }
}

/**
 * Convert a physical/display coordinate back into
 * the persistent logical board coordinate.
 *
 * This is the inverse of logicalToPhysical().
 */
export function physicalToLogical(
    coordinate: Coordinate,
    rotation: Rotation
): Coordinate {
    const {
        fileIndex,
        rankIndex,
    } = coordinate;

    switch (rotation) {
        case 0:
            return {
                fileIndex,
                rankIndex,
            };

        case 90:
            return {
                fileIndex: rankIndex,
                rankIndex: 7 - fileIndex,
            };

        case 180:
            return {
                fileIndex: 7 - fileIndex,
                rankIndex: 7 - rankIndex,
            };

        case 270:
            return {
                fileIndex: 7 - rankIndex,
                rankIndex: fileIndex,
            };
    }
}

/**
 * Convenience function:
 * logical square → physical coordinate.
 */
export function squareToPhysical(
    square: Square,
    rotation: Rotation
): Coordinate {
    return logicalToPhysical(
        squareToCoordinates(square),
        rotation
    );
}

/**
 * Convenience function:
 * physical coordinate → logical square.
 */
export function physicalToSquare(
    coordinate: Coordinate,
    rotation: Rotation
): Square {
    return coordinatesToSquare(
        coordinate.fileIndex,
        coordinate.rankIndex
    );
}

/**
 * Move one physical square in a direction.
 *
 * Physical coordinates use:
 *
 *      ↑ = rankIndex - 1
 *      ↓ = rankIndex + 1
 *      ← = fileIndex - 1
 *      → = fileIndex + 1
 */
export function movePhysical(
    coordinate: Coordinate,
    fileOffset: number,
    rankOffset: number
): Coordinate | null {
    const fileIndex =
        coordinate.fileIndex + fileOffset;

    const rankIndex =
        coordinate.rankIndex + rankOffset;

    if (
        fileIndex < 0 ||
        fileIndex >= 8 ||
        rankIndex < 0 ||
        rankIndex >= 8
    ) {
        return null;
    }

    return {
        fileIndex,
        rankIndex,
    };
}