import type {
    Color,
    GameState,
    GameStatus,
    Square,
} from "../types";

import {
    getPseudoLegalMoves,
    isSquareAttacked,
} from "./movement";

export function isValidMove(
    gameState: GameState,
    from: Square,
    to: Square
): boolean {
    const movingPiece =
        gameState.pieces.find(
            (piece) => piece.square === from
        );

    if (!movingPiece) {
        return false;
    }

    if (
        movingPiece.color !==
        gameState.turn
    ) {
        return false;
    }

    const legalMoves =
        getLegalMoves(
            movingPiece,
            gameState
        );

    return legalMoves.includes(to);
}

export function makeMove(
    gameState: GameState,
    from: Square,
    to: Square
): GameState | null {
    if (!isValidMove(gameState, from, to)) {
        return null;
    }

    const updatedPieces =
        gameState.pieces
            .filter(
                (piece) => piece.square !== to
            )
            .map((piece) => {
                if (piece.square === from) {
                    return {
                        ...piece,
                        square: to,
                        hasMoved: true,
                    };
                }

                return piece;
            });

    const nextTurn =
        gameState.turn === "white"
            ? "black"
            : "white";

    const newGameState: GameState = {
        ...gameState,
        pieces: updatedPieces,
        turn: nextTurn,
        status: "playing",
    };

    const status =
        getGameStatus(
            newGameState
        );

    return {
        ...newGameState,
        status,
    };
}

function findKing(
    color: "white" | "black",
    pieces: Piece[]
): Piece | undefined {
    return pieces.find(
        (piece) =>
            piece.type === "king" &&
            piece.color === color
    );
}

export function isKingInCheck(
    color: "white" | "black",
    pieces: Piece[]
): boolean {
    const king = findKing(
        color,
        pieces
    );

    if (!king) {
        return false;
    }

    const opponentColor =
        color === "white"
            ? "black"
            : "white";

    return isSquareAttacked(
        king.square,
        opponentColor,
        pieces
    );
}

export function getLegalMoves(
    piece: Piece,
    gameState: GameState
): Square[] {
    const pseudoLegalMoves =
        getPseudoLegalMoves(
            piece,
            gameState.pieces
        );

    const legalMoves: Square[] = [];

    for (const destination of pseudoLegalMoves) {
        const hypotheticalPieces =
            gameState.pieces
                .filter(
                    (otherPiece) =>
                        otherPiece.square !==
                        destination
                )
                .map((otherPiece) => {
                    if (
                        otherPiece.square ===
                        piece.square
                    ) {
                        return {
                            ...otherPiece,
                            square: destination,
                            hasMoved: true,
                        };
                    }

                    return otherPiece;
                });

        if (
            !isKingInCheck(
                piece.color,
                hypotheticalPieces
            )
        ) {
            legalMoves.push(
                destination
            );
        }
    }

    return legalMoves;
}

export function hasLegalMoves(
    gameState: GameState,
    color: Color
): boolean {
    const playerPieces =
        gameState.pieces.filter(
            (piece) => piece.color === color
        );

    for (const piece of playerPieces) {
        const legalMoves =
            getLegalMoves(
                piece,
                gameState
            );

        if (legalMoves.length > 0) {
            return true;
        }
    }

    return false;
}

export function getGameStatus(
    gameState: GameState
): GameStatus {
    const playerToMove =
        gameState.turn;

    const inCheck =
        isKingInCheck(
            playerToMove,
            gameState.pieces
        );

    const canMove =
        hasLegalMoves(
            gameState,
            playerToMove
        );

    if (inCheck && !canMove) {
        return "checkmate";
    }

    if (!inCheck && !canMove) {
        return "stalemate";
    }

    if (inCheck) {
        return "check";
    }

    return "playing";
}